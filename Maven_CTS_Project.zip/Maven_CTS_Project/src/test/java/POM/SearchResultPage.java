package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BasicUtilities.JustWait;
import BasicUtilities.ScreenShotss;
import BasicUtilities.logger;

public class SearchResultPage {
	WebDriver dr;
	logger log;
	ScreenShotss ss;
	JustWait wt;
	
	public SearchResultPage(WebDriver dr)
	{
	this.dr = dr;
	log =new logger(dr);
	ss=new ScreenShotss(dr);
	wt = new JustWait(dr);
	}
	
	public void addToCartBtn(int Product)
	{
			By by_ele = By.xpath("//div[@id='ContentPlaceHolder1_products']//div[@class='item col-lg-2 col-md-3 col-sm-4 col-xs-6']["+Product+"]//i");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.click();
	}
	
	public String verifySuccessfyllyAddedmsg() {
		By by_ele = By.xpath("//span[contains(text(),'Item successfully added')]");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		return we.getText();
	}
	
	public void checkOut() {
		By by_ele = By.xpath("//div[@class='col-xs-6 sec-check']//input[@type='button']");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.click();
	}
	
	public void continueShopping() {
		By by_ele = By.xpath("//input[@value='Continue Shopping']");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.click();
	}
	
	public void cart() {
		By by_ele = By.xpath("//a[@id='cart']");
		WebElement we = wt.WaitForElement(by_ele, 10);
		we=wt.elementToBeClickable(by_ele,10);
		we.click();
	}
	
	
}

