package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BasicUtilities.JustWait;
import BasicUtilities.ScreenShotss;
import BasicUtilities.logger;

public class ShoppingBasket {
	WebDriver dr;
	logger log;
	ScreenShotss ss;
	JustWait wt;
	
	public ShoppingBasket(WebDriver dr)
	{
	this.dr = dr;
	log =new logger(dr);
	ss=new ScreenShotss(dr);
	wt = new JustWait(dr);
	}
	

	public String bookName(int Rownumber)
	{
	By by_ele = By.xpath("//table[@id='ContentPlaceHolder1_GridView1']//tbody//tr["+(Rownumber+1)+"]//td[2]");
	WebElement we = wt.WaitForElement(by_ele, 10);
	we=wt.elementToBeClickable(by_ele,10);
	return we.getText();
	}	
	
	public String authorName(int Rownumber)
	{
	By by_ele = By.xpath("//table[@id='ContentPlaceHolder1_GridView1']//tbody//tr["+(Rownumber+1)+"]//td[3]");
	WebElement we = wt.WaitForElement(by_ele, 10);
	we=wt.elementToBeClickable(by_ele,10);
	return we.getText();
	}	
	
	public String Price(int Rownumber)
	{
	By by_ele = By.xpath("//table[@id='ContentPlaceHolder1_GridView1']//tbody//tr["+(Rownumber+1)+"]//td[5]");
	WebElement we = wt.WaitForElement(by_ele, 10);
	we=wt.elementToBeClickable(by_ele,10);
	return we.getText();
	}	
	
	public String total(int Rownumber)
	{
	By by_ele = By.xpath("//table[@id='ContentPlaceHolder1_GridView1']//tbody//tr["+(Rownumber+1)+"]//td[6]");
	WebElement we = wt.WaitForElement(by_ele, 10);
	we=wt.elementToBeClickable(by_ele,10);
	return we.getText();
	}	
}


