package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BasicUtilities.JustWait;
import BasicUtilities.ScreenShotss;
import BasicUtilities.logger;

public class AdvancedSearchPageDetail{

	WebDriver dr;
	logger log;
	ScreenShotss ss;
	JustWait wt;
	
	public AdvancedSearchPageDetail(WebDriver dr)
	{
	this.dr = dr;
	log =new logger(dr);
	ss=new ScreenShotss(dr);
	wt = new JustWait(dr);
	}
	
	public void title(String Title)
	{
			By by_ele = By.xpath("//input[@id='txt_title']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(Title);
	}
	
	public void author(String Author)
	{
			By by_ele = By.xpath("//input[@id='txt_author']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(Author);
	}
	
	public void publisher(String Publisher)
	{
			By by_ele = By.xpath("//input[@id='txt_author']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(Publisher);
	}
	
	public void ISBN(String isbn)
	{
			By by_ele = By.xpath("//input[@id='txt_author']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(isbn);
	}
	
	public void edition(String Edition)
	{
			By by_ele = By.xpath("//input[@id='txt_edition']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(Edition);
	}	
	
	public void keyword(String Keyword)
	{
			By by_ele = By.xpath("//input[@id='txt_edition']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(Keyword);
	}	
	
	public void JBA_BookCode(String bookcode)
	{
			By by_ele = By.xpath("//input[@id='txt_JbaCode']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(bookcode);
	}	
	
	public void AdvancedSearchBTN()
	{
			By by_ele = By.xpath("//input[@id='btn_advancedSearch']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.click();
	}
	
	public void ResetBTN()
	{
			By by_ele = By.xpath("//input[@name='Reset']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.click();
	}
	
	
	
}
