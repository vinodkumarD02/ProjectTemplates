package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import BasicUtilities.JustWait;
import BasicUtilities.ScreenShotss;
import BasicUtilities.logger;

public class AdvancedSearchPage {

	WebDriver dr;
	logger log;
	ScreenShotss ss;
	JustWait wt;
	
	public AdvancedSearchPage(WebDriver dr)
	{
	this.dr = dr;
	log =new logger(dr);
	ss=new ScreenShotss(dr);
	wt = new JustWait(dr);
	}
	
	public void title(String Title)
	{
			By by_ele = By.xpath("//input[@id='txt_title']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(Title);
	}
	
	public void author(String Author)
	{
			By by_ele = By.xpath("//input[@id='txt_author']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(Author);
	}
	
	public void publisher(String Publisher)
	{
			By by_ele = By.xpath("//input[@id='txt_author']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(Publisher);
	}
	
	public void ISBN(String isbn)
	{
			By by_ele = By.xpath("//input[@id='txt_author']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(isbn);
	}
	
	public void edition(String Edition)
	{
			By by_ele = By.xpath("//input[@id='txt_author']");
			WebElement we = wt.WaitForElement(by_ele, 10);
			we=wt.elementToBeClickable(by_ele,10);
			we.sendKeys(Edition);
	}
	
}
