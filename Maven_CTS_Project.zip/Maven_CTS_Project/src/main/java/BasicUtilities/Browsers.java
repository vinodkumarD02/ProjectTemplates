package BasicUtilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Browsers {
	
	public String Chrome ="CHROME";
	public String FireFox="Firefox";
	WebDriver dr;
	logger log;
	
	public WebDriver launchBrowser(String BrowserType, String Url)
	{
		
		if(BrowserType.equalsIgnoreCase("Chrome"))
		{
			String DriverPath ="src\\test\\resources\\Drivers\\chromedriver_v79.exe";
			System.setProperty("webdriver.chrome.driver", DriverPath);
			 dr = new ChromeDriver(); 
			 dr.manage().window().maximize();
			 dr.get(Url);
			 dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			 log=new logger(dr);
			 log.Update_log("chrome browser Successfully Launched!!");

		}
		else if(BrowserType.equalsIgnoreCase("FireFox"))
		
		{
			String DriverPath ="src\\test\\resources\\Drivers\\geckodriver.exe";
			System.setProperty("webdriver.gecko.driver", DriverPath);
			 dr = new FirefoxDriver(); 
			 dr.get(Url);
			 dr.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			 log=new logger(dr);
			 log.Update_log("FiREfox  browser Successfully Launched!!");
	
		}
		
		return dr;
	}


}
